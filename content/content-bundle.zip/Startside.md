Velkommen til bloggen om alt som er dansk og interessant for især svenske interesserede, men ingen skal føle sig udenfor, alle er velkommen på denne blog. En blog som forsøger at udgive et nyhedsbrev hver søndag om hvad der er sket i Danmark, hvilken ny kultur man skal holde øje med og artikler om alt fra dansk sprog, kultur, historie og lignende (ofte med udgangspunkt i et svensktalende publikum).




## Skriv dig op til nyhedsbrevet her!









<iframe src="https://witty-teacher-2971.ck.page/517c4edaf6" style="width:100%; height:800; border:none; margin-top:-60px"></iframe>
